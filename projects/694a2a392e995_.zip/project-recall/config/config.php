<?php
/**
 * Project Recall - Main Configuration File
 */

// ตั้งค่า error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ตั้งค่า timezone
date_default_timezone_set('Asia/Bangkok');

// ตั้งค่าพื้นฐานของแอพพลิเคชัน
const APP_CONFIG = [
    // ข้อมูลแอพพลิเคชัน
    'app_name' => 'Project Recall',
    'app_version' => '1.0.0',
    'app_url' => '',  // ใส่ URL หลักของเว็บไซต์
    
    // การตั้งค่าภาษา
    'default_language' => 'th',
    'available_languages' => ['th', 'en'],
    
    // การตั้งค่าเซสชัน
    'session' => [
        'lifetime' => 7200,  // 2 ชั่วโมง
        'path' => '/',
        'domain' => '',  // ใส่โดเมนถ้ามี
        'secure' => false,  // ตั้งเป็น true ถ้าใช้ HTTPS
        'httponly' => true,
        'name' => 'RECALL_SESSION'
    ],
    
    // การตั้งค่า Database (ถ้าใช้ SQLite)
    'database' => [
        'type' => 'sqlite',  // mysql หรือ sqlite
        'sqlite_path' => __DIR__ . '/../data/database.sqlite',
        // สำหรับ MySQL
        'mysql' => [
            'host' => 'localhost',
            'dbname' => 'project_recall',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8mb4'
        ]
    ],
    
    // ค่าคงที่สำหรับรูปภาพ
    'images' => [
        'logo_path' => 'photo/img/Project_Recall.png',
        'upload_path' => 'uploads/',
        'max_size' => 5242880  // 5MB
    ],
    
    // การตั้งค่าความปลอดภัย
    'security' => [
        'password_algo' => PASSWORD_DEFAULT,
        'password_options' => [
            'cost' => 12
        ],
        'max_login_attempts' => 5,
        'lockout_time' => 900  // 15 นาที
    ]
];

// ฟังก์ชันสำหรับดึงค่า config
function config(string $key, $default = null) {
    $keys = explode('.', $key);
    $config = APP_CONFIG;
    
    foreach ($keys as $segment) {
        if (!isset($config[$segment])) {
            return $default;
        }
        $config = $config[$segment];
    }
    
    return $config;
}
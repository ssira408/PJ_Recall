<?php
/**
 * Project Recall - Forget Password Page
 */

require_once __DIR__ . '/includes/bootstrap.php';

if (isPost()) {
    $email = post('email');

    if (empty($email)) {
        setFlash('error', 'กรุณากรอกอีเมล');
    } elseif (!isValidEmail($email)) {
        setFlash('error', 'รูปแบบอีเมลไม่ถูกต้อง');
    } else {
        // TODO: ตรวจสอบว่าอีเมลมีอยู่ในระบบหรือไม่
        // TODO: สร้าง token และส่งอีเมลรีเซ็ตรหัสผ่านจริง

        // mock response
        setFlash('success', 'หากอีเมลนี้อยู่ในระบบ เราได้ส่งลิงก์รีเซ็ตรหัสผ่านให้แล้ว');
    }
}

$flash = getFlash();
?>
<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ลืมรหัสผ่าน - Project Recall</title>
  <link rel="stylesheet" href="css/login.css">
</head>
<body>
  <div class="wrap">
    <div class="hero" aria-hidden="true">
      <img src="photo/img/Project_Recall.png" alt="Project Recall logo">
    </div>
    <div class="panel">
      <div class="card" role="region" aria-label="Forget Password form">
        <h1>ลืมรหัสผ่าน</h1>
        <p class="lead">กรอกอีเมลของคุณเพื่อรับลิงก์รีเซ็ตรหัสผ่าน</p>

        <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?>">
            <?= e($flash['message']) ?>
        </div>
        <?php endif; ?>

        <form method="post" action="<?= url('forget.php') ?>" novalidate>
          <div class="field">
            <label for="email">อีเมล</label>
            <input id="email" name="email" type="email" required placeholder="you@ตัวอย่าง.com">
          </div>

          <button type="submit" class="btn-primary">ส่งลิงก์รีเซ็ตรหัสผ่าน</button>
        </form>

        <div class="link-small">
            <a href="login.php">กลับไปหน้าเข้าสู่ระบบ</a>
        </div>
      </div>
    </div>
  </div>
</body>
</html>

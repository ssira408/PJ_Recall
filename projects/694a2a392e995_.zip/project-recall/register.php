<?php
/**
 * Project Recall - Register Page
 */

// Load bootstrap
require_once __DIR__ . '/includes/bootstrap.php';

// Process registration form
if (isPost()) {
    $name = post('name');
    $email = post('email');
    $password = post('password');
    $passwordConfirm = post('password_confirm');
    $dob = post('dob');
    $gender = post('gender');
    
    $errors = [];
    
    // Validate input
    if (empty($name)) {
        $errors[] = 'กรุณากรอกชื่อ';
    }
    if (empty($email)) {
        $errors[] = 'กรุณากรอกอีเมล';
    } elseif (!isValidEmail($email)) {
        $errors[] = 'รูปแบบอีเมลไม่ถูกต้อง';
    }
    if (empty($password)) {
        $errors[] = 'กรุณากรอกรหัสผ่าน';
    } elseif (strlen($password) < 8) {
        $errors[] = 'รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร';
    }
    if ($password !== $passwordConfirm) {
        $errors[] = 'รหัสผ่านไม่ตรงกัน';
    }
    if (empty($dob)) {
        $errors[] = 'กรุณากรอกวันเกิด';
    }
    if (empty($gender)) {
        $errors[] = 'กรุณาเลือกเพศ';
    }
    
    if (!empty($errors)) {
        setFlash('error', implode('<br>', $errors));
    }
    // TODO: Add actual registration logic when database is ready
}

// Get any flash messages
$flash = getFlash();
?>
<!doctype html>
<html lang="th">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register - Project Recall</title>
    <link rel="stylesheet" href="css/register.css">
  </head>
  <body>
    <div class="wrap">
      <div class="hero" aria-hidden="true">
        <img src="photo/img/Project_Recall.png" alt="Project Recall logo">
      </div>
      <div class="panel">
        <div class="card" role="region" aria-label="Register form">
          <h1>ลงทะเบียน</h1>
          <p class="lead">โปรดกรอกข้อมูลเพื่อสร้างบัญชี</p>
          <?php if ($flash): ?>
          <div class="alert alert-<?= e($flash['type']) ?>">
              <?= e($flash['message']) ?>
          </div>
          <?php endif; ?>
          <form method="post" action="<?= url('register.php') ?>" novalidate>
            <div class="field">
              <label for="name">ชื่อ</label>
              <input id="name" name="name" type="text" placeholder="ชื่อ-นามสกุล">
            </div>
            <div class="field">
              <label for="email">อีเมล</label>
              <input id="email" name="email" type="email" placeholder="you@ตัวอย่าง.com">
            </div>
            <div class="field">
              <label for="pass">รหัสผ่าน</label>
              <input id="pass" name="password" type="password" placeholder="รหัสผ่าน">
            </div>
            <div class="field">
              <label for="pass2">ยืนยันรหัสผ่าน</label>
              <input id="pass2" name="password_confirm" type="password" placeholder="ยืนยันรหัสผ่าน">
            </div>
            <div class="field">
              <label for="dob">วัน/เดือน/ปี</label>
              <input id="dob" name="dob" type="text" placeholder="dd/mm/yyyy">
            </div>
            <div class="field">
              <label for="gender">เพศ</label>
              <select id="gender" name="gender">
                <option value="">เลือกเพศ</option>
                <option value="male">ชาย</option>
                <option value="female">หญิง</option>
                <option value="other">อื่นๆ</option>
              </select>
            </div>
            <button type="submit" class="btn-primary">ลงทะเบียน</button>
          </form>
          <div class="link-small"><a href="login.php">เข้าสู่ระบบ</a></div>
        </div>
      </div>
    </div>
  </body>
</html>

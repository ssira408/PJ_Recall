<?php
/**
 * Project Recall - Bootstrap File
 * โหลดไฟล์และตั้งค่าที่จำเป็นสำหรับแอพพลิเคชัน
 */

// ตั้งค่า strict types
declare(strict_types=1);

// โหลดไฟล์ config
require_once __DIR__ . '/../config/config.php';

// เริ่ม session ถ้ายังไม่ได้เริ่ม
if (session_status() === PHP_SESSION_NONE) {
    // ตั้งค่า session ตาม config
    session_name(config('session.name'));
    session_set_cookie_params(
        config('session.lifetime'),
        config('session.path'),
        config('session.domain'),
        config('session.secure'),
        config('session.httponly')
    );
    session_start();
}

// ฟังก์ชันช่วยเหลือพื้นฐาน
require_once __DIR__ . '/helpers.php';

// ตั้งค่า error handling
set_error_handler('errorHandler');
set_exception_handler('exceptionHandler');

// ตั้งค่า autoloading (ถ้าใช้ Composer ในอนาคต)
// require_once __DIR__ . '/../vendor/autoload.php';
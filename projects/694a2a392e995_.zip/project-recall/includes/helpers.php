<?php
/**
 * Project Recall - Helper Functions
 */

/**
 * Escape HTML entities in a string
 */
function e(string $string): string {
    return htmlspecialchars($string, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Get absolute URL for a path
 */
function url(string $path = ''): string {
    $base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
    return $base . '/' . ltrim($path, '/');
}

/**
 * Custom error handler
 */
function errorHandler($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) {
        return;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
}

/**
 * Custom exception handler
 */
function exceptionHandler($exception) {
    $isDebug = true; // ตั้งเป็น false ใน production
    
    if ($isDebug) {
        echo '<h1>Error</h1>';
        echo '<p>Message: ' . e($exception->getMessage()) . '</p>';
        echo '<p>File: ' . e($exception->getFile()) . '</p>';
        echo '<p>Line: ' . $exception->getLine() . '</p>';
        echo '<h2>Stack Trace:</h2>';
        echo '<pre>' . e($exception->getTraceAsString()) . '</pre>';
    } else {
        // Log error และแสดงหน้า error ที่เป็นมิตรกับผู้ใช้
        error_log($exception->getMessage());
        include __DIR__ . '/../templates/error.php';
    }
    
    exit(1);
}

/**
 * Validate email address
 */
function isValidEmail(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Check if request is POST
 */
function isPost(): bool {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

/**
 * Get POST data with optional filtering
 */
function post(string $key, $default = null) {
    $value = $_POST[$key] ?? $default;
    return is_string($value) ? trim($value) : $value;
}

/**
 * Set flash message
 */
function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

/**
 * Get and clear flash message
 */
function getFlash(): ?array {
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

/**
 * Check if user is logged in
 */
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

/**
 * Redirect to a URL
 */
function redirect(string $path): void {
    header('Location: ' . url($path));
    exit;
}
<?php
/**
 * Project Recall - Main Index Page
 */

// Load bootstrap
require_once __DIR__ . '/includes/bootstrap.php';

// Check logo exists and prepare background CSS
$logoPath = config('images.logo_path');
$logoAbs = __DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $logoPath);
$hasLogo = is_file($logoAbs) && filesize($logoAbs) > 0;
$bgCss = 'linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0))' . 
         ($hasLogo ? ", url('" . e($logoPath) . "')" : '');

// Generate URLs for login and register
$loginUrl = url('login.php');
$registerUrl = url('register.php');
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Project Recall</title>
	<link rel="stylesheet" href="css/style.css">
	<style>
		/* background-image kept inline because it uses PHP variable $bgCss */
		body{background-image: <?php echo $bgCss; ?>;}
	</style>
</head>
<body>
<div class="page-transition"></div>
<a class="skip" href="#main">ข้ามไปยังเนื้อหา</a>
<div class="shell">
<main id="main" class="card" role="main">
<div class="buttons">
<a class="btn" href="<?= e($loginUrl) ?>" aria-label="เข้าสู่ระบบ" onclick="startTransition(event)">เข้าสู่ระบบ</a>
<a class="btn alt" href="<?= e($registerUrl) ?>" aria-label="ลงทะเบียน" onclick="startTransition(event)">ลงทะเบียน</a>
</div>
<div class="divider" aria-hidden="true"></div>
</main>
</div>
<script>
// รีเซ็ต transition เมื่อโหลดหน้า
document.addEventListener('DOMContentLoaded', () => {
    const transition = document.querySelector('.page-transition');
    transition.classList.remove('active');
    
    // เพิ่ม fade in animation สำหรับหน้า index
    requestAnimationFrame(() => {
        document.body.style.opacity = '0';
        requestAnimationFrame(() => {
            document.body.style.transition = 'opacity 0.6s ease';
            document.body.style.opacity = '1';
        });
    });
});

// จัดการ transition เมื่อคลิกปุ่ม
function startTransition(e) {
    e.preventDefault();
    const target = e.target.href;
    const transition = document.querySelector('.page-transition');
    
    transition.classList.add('active');
    
    setTimeout(() => {
        window.location.href = target;
    }, 600);
}

// จัดการ back/forward navigation
window.addEventListener('pageshow', (event) => {
    if (event.persisted) {
        // หน้าถูกโหลดจาก bfcache (back/forward cache)
        const transition = document.querySelector('.page-transition');
        transition.classList.remove('active');
        
        requestAnimationFrame(() => {
            document.body.style.opacity = '0';
            requestAnimationFrame(() => {
                document.body.style.transition = 'opacity 0.6s ease';
                document.body.style.opacity = '1';
            });
        });
    }
});
</script>
<noscript>
<div style="position:fixed;left:8px;bottom:8px;padding:8px 12px;background:#222;color:#fff;border-radius:6px">กรุณาเปิด JavaScript เพื่อประสบการณ์ที่ดีที่สุด</div>
</noscript>
</body>
</html>

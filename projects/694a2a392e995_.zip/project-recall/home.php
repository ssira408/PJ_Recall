<?php
/**
 * Project Recall - Home Page
 */

require_once __DIR__ . '/includes/bootstrap.php';

// ใช้ session แทน authUser()
$user = $_SESSION['user'] ?? null;

// Flash message
$flash = getFlash();
?>
<!doctype html>
<html lang="th">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Project Recall - หน้าแรก</title>
    <link rel="stylesheet" href="css/home.css">
  </head>

  <body>
    <div class="wrap">

      <!-- โลโก้ด้านบน -->
      <header class="hero">
        <img src="photo/img/PRC-logo.png" alt="Project Recall logo">
      </header>

      <!-- Top Bar -->
      <div class="topbar">
        <div class="left">หน้าหลัก · เมนูโครงงาน</div>
        <div class="right">
          <?= e($user['name'] ?? 'ผู้ใช้'); ?>
        </div>
      </div>

      <main class="panel">

        <div class="card">

          <h1>ค้นหาโครงงานที่เก็บไว้</h1>

          <!-- FLASH MESSAGE -->
          <?php if ($flash): ?>
            <div class="alert alert-<?= e($flash['type']) ?>">
              <?= e($flash['message']) ?>
            </div>
          <?php endif; ?>

          <!-- 🔍 ช่องค้นหา -->
          <div class="search-row">
            <div class="search-input">
              <input type="text" placeholder="ชื่อโครงงานที่ต้องการ">
              <button class="btn-search">🔍</button>
            </div>
          </div>

          <!-- 🎛 ฟิลเตอร์ -->
          <div class="filter-row">

            <div class="filter-box">
              <label>ปี พ.ศ.</label>
              <select>
                <option>--เลือก--</option>
                <option>2561</option>
                <option>2562</option>
                <option>2563</option>
                <option>2564</option>
              </select>
            </div>

            <div class="filter-box">
              <label>แผนก</label>
              <select>
                <option>--เลือก--</option>
                <option>IT</option>
                <option>HR</option>
              </select>
            </div>

            <div class="filter-box">
              <label>ครู/อาจารย์ที่ปรึกษา</label>
              <select>
                <option>--เลือก--</option>
                <option>ครูสมชาย</option>
                <option>ครูสมหญิง</option>
              </select>
            </div>

          </div>

          <!-- ปุ่ม -->
          <div class="actions-row">
            <button class="btn-save">บันทึก</button>
            <button class="btn-clear">ล้างค่า</button>
          </div>
        </div>
      </main>
      <main class="panel">
        <div class="card">
          <div class="years">
            <button class="year-btn">2561</button>
            <button class="year-btn">2562</button>
            <button class="year-btn">2563</button>
            <button class="year-btn">2564</button>
            <button class="year-btn">2566</button>
          </div>
        </div>
      </main>
    </div>
  </body>
</html>

<?php
/**
 * Project Recall - Login Page
 */

// Load bootstrap
require_once __DIR__ . '/includes/bootstrap.php';

// Process login form
if (isPost()) {
    $email = post('email');
    $password = post('password');
    $remember = (bool)post('remember');

    if (empty($email) || empty($password)) {
        setFlash('error', 'กรุณากรอกอีเมลและรหัสผ่าน');
    } elseif (!isValidEmail($email)) {
        setFlash('error', 'รูปแบบอีเมลไม่ถูกต้อง');
    }
    // TODO: Add actual login logic when database is ready
}

// Get any flash messages
$flash = getFlash();
?>
<!doctype html>
<html lang="th">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - Project Recall</title>
    <link rel="stylesheet" href="css/login.css">
  </head>
  <body>
    <div class="wrap">
      <div class="hero" aria-hidden="true">
        <img src="photo/img/Project_Recall.png" alt="Project Recall logo">
      </div>
      <div class="panel">
        <div class="card" role="region" aria-label="Login form">
          <h1>เข้าสู่ระบบ</h1>
          <p class="lead">โปรดกรอกข้อมูลเพื่อเข้าสู่ระบบ</p>
          <?php if ($flash): ?>
          <div class="alert alert-<?= e($flash['type']) ?>">
              <?= e($flash['message']) ?>
          </div>
          <?php endif; ?>
          <form method="post" action="<?= url('login.php') ?>" novalidate>
            <div class="field">
              <label for="email">อีเมล</label>
              <input id="email" name="email" type="email" required placeholder="you@ตัวอย่าง.com">
            </div>
            <div class="field">
              <label for="password">รหัสผ่าน</label>
              <input id="password" name="password" type="password" required placeholder="รหัสผ่านของคุณ">
            </div>
            <div class="row">
              <label class="checkbox"><input type="checkbox" name="remember"> จดจำฉัน</label>
              <a href="forget.php" style="color:#666;text-decoration:none">ลืมรหัสผ่าน?</a>
            </div>
            <button type="submit" class="btn-primary">เข้าสู่ระบบ</button>
          </form>
          <div class="link-small"><a href="register.php">ลงทะเบียน</a></div>
        </div>
      </div>
    </div>
  </body>
</html>
